<?php
session_start();

// 生成随机字符串
$captcha_code = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"), 0, 6);
$_SESSION['captcha'] = $captcha_code;

// 创建图像
$image = imagecreatetruecolor(150, 50);

// 设置背景颜色
$bg_color = imagecolorallocate($image, 255, 255, 255); // 白色
imagefill($image, 0, 0, $bg_color);

// 设置文本颜色
$text_color = imagecolorallocate($image, 0, 0, 0); // 黑色

// 设置字体
$font = __DIR__ . '/captcha.ttf'; // 替换为你的字体文件路径 (例如 Arial.ttf)

// 检查字体文件是否存在
if (!file_exists($font)) {
    die("字体文件不存在: " . $font);
}

// 添加文本
imagettftext($image, 20, rand(-10, 10), 20, 35, $text_color, $font, $captcha_code);

// 添加干扰线
for ($i = 0; $i < 5; $i++) {
    $line_color = imagecolorallocate($image, rand(0, 255), rand(0, 255), rand(0, 255));
    imageline($image, rand(0, 150), 0, rand(0, 150), 50, $line_color);
}

// 输出图像
header('Content-type: image/png');
imagepng($image);

// 销毁图像
imagedestroy($image);
?>
