<?php
// 检查是否已安装
if (!file_exists('config.php')) {
    header('Location: install.php');
    exit;
}

require_once 'config.php';

// 数据库连接
try {
    $db = new PDO("mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}

session_start();

// 检查用户是否已登录
if (isset($_SESSION['user_id'])) {
    // 获取用户信息
    $stmt = $db->prepare("SELECT is_admin FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if ($user) {
        // 判断用户角色
        if ($user['is_admin'] == 1) {
            // 管理员
            header('Location: admin/index.php');
            exit;
        } else {
            // 普通用户
            header('Location: user/dashboard.php');
            exit;
        }
    } else {
        // 用户信息不存在，清除 session 并重定向到登录页面
        session_destroy();
        header('Location: index.php');
        exit;
    }
}

// 登录处理
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // 检查登录尝试次数
    $stmt = $db->prepare("SELECT login_attempts, last_attempt_time FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user_data = $stmt->fetch();

    if ($user_data) {
        $login_attempts = $user_data['login_attempts'];
        $last_attempt_time = $user_data['last_attempt_time'];

        if ($login_attempts >= 30 && $last_attempt_time > date('Y-m-d H:i:s', strtotime('-1 hour'))) {
            $login_error = "您的账户已被锁定 1 小时，请稍后再试。";
        } else {
            $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                // 重置登录尝试次数
                $stmt = $db->prepare("UPDATE users SET login_attempts = 0, last_attempt_time = NULL WHERE username = ?");
                $stmt->execute([$username]);

                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];

                // 管理员判断
                if ($user['is_admin'] == 1) {
                    $_SESSION['is_admin'] = true;
                    header('Location: admin/index.php');
                    exit;
                } else {
                    header('Location: user/dashboard.php');
                    exit;
                }
            } else {
                // 增加登录尝试次数
                $stmt = $db->prepare("UPDATE users SET login_attempts = login_attempts + 1, last_attempt_time = NOW() WHERE username = ?");
                $stmt->execute([$username]);

                $login_error = "用户名或密码错误";
            }
        }
    } else {
        $login_error = "用户名或密码错误";
    }
}

// 登出处理
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="./assess/css/style.css">
    <title>简洁图床系统</title>
</head>

<body>
    <div class="container">
        <header>
            <div class="logo">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M4 8H20M8 4V20M7.8 20H16.2C17.8802 20 18.7202 20 19.362 19.673C19.9265 19.3854 20.3854 18.9265 20.673 18.362C21 17.7202 21 16.8802 21 15.2V8.8C21 7.11984 21 6.27976 20.673 5.63803C20.3854 5.07354 19.9265 4.6146 19.362 4.32698C18.7202 4 17.8802 4 16.2 4H7.8C6.11984 4 5.27976 4 4.63803 4.32698C4.07354 4.6146 3.6146 5.07354 3.32698 5.63803C3 6.27976 3 7.11984 3 8.8V15.2C3 16.8802 3 17.7202 3.32698 18.362C3.6146 18.9265 4.07354 19.3854 4.63803 19.673C5.27976 20 6.11984 20 7.8 20Z"
                        stroke="#4361ee" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    <circle cx="12" cy="12" r="2" stroke="#4361ee" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                </svg>
                <span>简洁图床</span>
            </div>

            <?php if (isset($_SESSION['username'])) : ?>
            <div class="user-info">
                <span>欢迎, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="?logout=1" class="logout-btn">退出登录</a>
            </div>
            <?php else : ?>
            <div class="auth-buttons">
                <a href="#login" class="login-btn">登录</a>
                <?php if (REGISTRATION_MODE != 'disabled') : ?>
                <a href="user/register.php" class="register-btn">注册</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </header>

        <?php if (!isset($_SESSION['username'])) : ?>
        <div class="login-form" id="login">
            <h2>用户登录</h2>

            <?php if (isset($login_error)) : ?>
            <div class="error"><?php echo $login_error; ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label for="username">用户名</label>
                    <input type="text" id="username" name="username" required>
                </div>

                <div class="form-group">
                    <label for="password">密码</label>
                    <input type="password" id="password" name="password" required>
                </div>

                <button type="submit" name="login" class="submit-btn">登录</button>
                <?php if (REGISTRATION_MODE != 'disabled') : ?>
                <p style="text-align: center; margin-top: 15px;">没有账号？<a href="user/register.php"
                        class="toggle-form">去注册</a></p>
                <?php endif; ?>
            </form>
        </div>
        <?php endif; ?>
    </div>

    <script>
    // 表单切换功能
    document.querySelectorAll('.login-btn, .register-btn, .toggle-form').forEach(btn => {
        btn.addEventListener('click', function(e) {
            if (this.getAttribute('href') === '#login' || this.classList.contains('login-btn')) {
                document.querySelector('.login-form').style.display = 'block';
            }

            if (this.getAttribute('href')?.startsWith('#')) {
                e.preventDefault();
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            }
        });
    });

    // 默认显示登录表单
    if (document.querySelector('.login-form')) {
        document.querySelector('.login-form').style.display = 'block';
    }
    </script>
</body>

</html>
