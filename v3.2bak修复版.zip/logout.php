<?php
session_start();

// 销毁所有 session 数据
session_destroy();

// 重定向到首页
header('Location: ../index.php');
exit;
?>
