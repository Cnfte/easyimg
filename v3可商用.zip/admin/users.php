<?php
require_once '../config.php';

session_start();

// 检查用户是否登录
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin'])) {
    header('Location: ../index.php');
    exit;
}

// 数据库连接
try {
    $db = new PDO("mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}

// 批量删除用户处理
if (isset($_POST['delete_selected'])) {
    if (isset($_POST['user_ids']) && is_array($_POST['user_ids'])) {
        $user_ids = $_POST['user_ids'];

        // 避免删除自己
        if (in_array($_SESSION['user_id'], $user_ids)) {
            echo "<script>alert('不能删除自己！');window.location.href='users.php';</script>";
            exit;
        }

        // 构建 IN 子句
        $placeholders = implode(',', array_fill(0, count($user_ids), '?'));

        // 删除用户
        $stmt = $db->prepare("DELETE FROM users WHERE id IN ($placeholders)");
        $stmt->execute($user_ids);

        // 删除用户相关的图片 (可选)
        $stmt = $db->prepare("DELETE FROM images WHERE user_id IN ($placeholders)");
        $stmt->execute($user_ids);

        header('Location: users.php');
        exit;
    } else {
        echo "<script>alert('请选择要删除的用户！');window.location.href='users.php';</script>";
        exit;
    }
}

// 获取所有用户
$users = [];
$stmt = $db->prepare("SELECT * FROM users ORDER BY id DESC");
$stmt->execute();
$users = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../assess/css/style.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="icon" href="../index.png" type="image/x-icon">
    <link rel="shortcut icon" href="../index.png" type="image/x-icon">
    <title>用户管理</title>
    <style>
        .user-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .user-table th,
        .user-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        .user-table th {
            background-color: #f2f2f2;
        }

        .delete-user-btn {
            background-color: #e5383b;
            color: #fff;
            padding: 5px 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <div class="container">
        <header>
            <div class="logo">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M4 8H20M8 4V20M7.8 20H16.2C17.8802 20 18.7202 20 19.362 19.673C19.9265 19.3854 20.3854 18.9265 20.673 18.362C21 17.7202 21 16.8802 21 15.2V8.8C21 7.11984 21 6.27976 20.673 5.63803C20.3854 5.07354 19.9265 4.6146 19.362 4.32698C18.7202 4 17.8802 4 16.2 4H7.8C6.11984 4 5.27976 4 4.63803 4.32698C4.07354 4.6146 3.6146 5.07354 3.32698 5.63803C3 6.27976 3 7.11984 3 8.8V15.2C3 16.8802 3 17.7202 3.32698 18.362C3.6146 18.9265 4.07354 19.3854 4.63803 19.673C5.27976 20 6.11984 20 7.8 20Z"
                        stroke="#4361ee" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    <circle cx="12" cy="12" r="2" stroke="#4361ee" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                </svg>
                <span>简洁图床 - 用户管理</span>
            </div>

            <div class="user-info">
                <span>管理员, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="../index.php?logout=1" class="logout-btn">退出登录</a>
            </div>
        </header>

        <div class="admin-panel">
            <h2>用户管理</h2>

            <form method="POST">
                <table class="user-table">
                    <thead>
                        <tr>
                            <th>选择</th>
                            <th>ID</th>
                            <th>用户名</th>
                            <th>邮箱</th>
                            <th>注册时间</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user) : ?>
                        <tr>
                            <td><input type="checkbox" name="user_ids[]" value="<?php echo $user['id']; ?>"></td>
                            <td><?php echo htmlspecialchars($user['id']); ?></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['email'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($user['register_time']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <button type="submit" name="delete_selected" class="delete-user-btn"
                    onclick="return confirm('确定要删除选中的用户吗？')">删除选中</button>
            </form>
        </div>
    </div>
</body>

</html>
