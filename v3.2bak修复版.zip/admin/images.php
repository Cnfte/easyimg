<?php
require_once '../config.php';

session_start();

// 检查用户是否登录
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin'])) {
    header('Location: ../index.php');
    exit;
}

// 数据库连接
try {
    $db = new PDO("mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}

// 批量删除图片处理
if (isset($_POST['delete_selected'])) {
    if (isset($_POST['image_ids']) && is_array($_POST['image_ids'])) {
        $image_ids = $_POST['image_ids'];

        // 获取图片信息
        $stmt = $db->prepare("SELECT * FROM images WHERE id IN (" . implode(',', array_fill(0, count($image_ids), '?')) . ")");
        $stmt->execute($image_ids);
        $images = $stmt->fetchAll();

        // 删除文件
        foreach ($images as $image) {
            $file_path = '../uploads/' . $image['filename'];
            if (file_exists($file_path)) {
                unlink($file_path);
            }
        }

        // 删除数据库记录
        $stmt = $db->prepare("DELETE FROM images WHERE id IN (" . implode(',', array_fill(0, count($image_ids), '?')) . ")");
        $stmt->execute($image_ids);

        header('Location: images.php');
        exit;
    } else {
        echo "<script>alert('请选择要删除的图片！');window.location.href='images.php';</script>";
        exit;
    }
}

// 获取所有图片
$images = [];
$stmt = $db->prepare("SELECT images.*, users.username FROM images INNER JOIN users ON images.user_id = users.id ORDER BY upload_date DESC");
$stmt->execute();
$images = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../assess/css/style.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>图片管理</title>
    <style>
        .image-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .image-table th,
        .image-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        .image-table th {
            background-color: #f2f2f2;
        }

        .delete-image-btn {
            background-color: #e5383b;
            color: #fff;
            padding: 5px 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
        }

        .image-preview {
            max-width: 100px;
            max-height: 100px;
        }

        /* 修复移动设备上选中框无法使用的问题 */
        .image-table td input[type="checkbox"] {
            width: 20px;
            height: 20px;
            vertical-align: middle;
        }

        /* 响应式设计 */
        @media (max-width: 768px) {
            .image-table {
                font-size: 14px;
            }

            .image-table th,
            .image-table td {
                padding: 5px;
            }

            .delete-image-btn {
                font-size: 12px;
            }

            .image-preview {
                max-width: 80px;
                max-height: 80px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <header>
            <div class="logo">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M4 8H20M8 4V20M7.8 20H16.2C17.8802 20 18.7202 20 19.362 19.673C19.9265 19.3854 20.3854 18.9265 20.673 18.362C21 17.7202 21 16.8802 21 15.2V8.8C21 7.11984 21 6.27976 20.673 5.63803C20.3854 5.07354 19.9265 4.6146 19.362 4.32698C18.7202 4 17.8802 4 16.2 4H7.8C6.11984 4 5.27976 4 4.63803 4.32698C4.07354 4.6146 3.6146 5.07354 3.32698 5.63803C3 6.27976 3 7.11984 3 8.8V15.2C3 16.8802 3 17.7202 3.32698 18.362C3.6146 18.9265 4.07354 19.3854 4.63803 19.673C5.27976 20 6.11984 20 7.8 20Z"
                        stroke="#4361ee" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    <circle cx="12" cy="12" r="2" stroke="#4361ee" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                </svg>
                <span>简洁图床 - 图片管理</span>
            </div>

            <div class="user-info">
                <span>管理员, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="../index.php?logout=1" class="logout-btn">退出登录</a>
            </div>
        </header>

        <div class="admin-panel">
            <h2>图片管理</h2>

            <form method="POST">
                <table class="image-table">
                    <thead>
                        <tr>
                            <th>选择</th>
                            <th>ID</th>
                            <th>用户名</th>
                            <th>文件名</th>
                            <th>原始文件名</th>
                            <th>上传时间</th>
                            <th>预览</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($images as $image) : ?>
                        <tr>
                            <td><input type="checkbox" name="image_ids[]" value="<?php echo $image['id']; ?>"></td>
                            <td><?php echo htmlspecialchars($image['id']); ?></td>
                            <td><?php echo htmlspecialchars($image['username']); ?></td>
                            <td><?php echo htmlspecialchars($image['filename']); ?></td>
                            <td><?php echo htmlspecialchars($image['original_name']); ?></td>
                            <td><?php echo htmlspecialchars($image['upload_date']); ?></td>
                            <td>
                                <?php if (pathinfo($image['filename'], PATHINFO_EXTENSION) === 'mp4') : ?>
                                <video class="image-preview" controls>
                                    <source src="../uploads/<?php echo htmlspecialchars($image['filename']); ?>"
                                        type="video/mp4">
                                    您的浏览器不支持视频播放
                                </video>
                                <?php else : ?>
                                <img src="../uploads/<?php echo htmlspecialchars($image['filename']); ?>"
                                    alt="<?php echo htmlspecialchars($image['original_name']); ?>" class="image-preview">
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <button type="submit" name="delete_selected" class="delete-image-btn"
                    onclick="return confirm('确定要删除选中的图片吗？')">删除选中</button>
            </form>
        </div>
    </div>
</body>

</html>
