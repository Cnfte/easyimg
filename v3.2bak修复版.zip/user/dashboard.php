<?php
require_once '../config.php';

session_start();

// 检查用户是否登录
if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

// 数据库连接
try {
    $db = new PDO("mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}

// 文件上传处理
if (isset($_FILES['image'])) {
    $file = $_FILES['image'];
    $allowed_extensions = ['mp4', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'heif'];
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if ($file['error'] === UPLOAD_ERR_OK) {
        // 检查文件类型
        if (!in_array($file_ext, $allowed_extensions)) {
            $upload_error = "只允许上传以下格式的文件: .mp4, .png, .jpg, .jpeg, .gif, .webp, .heif";
        } else {
            $new_filename = uniqid() . '.' . $file_ext;
            $upload_path = '../uploads/' . $new_filename;

            // 检查目标目录是否存在
            if (!is_dir('../uploads/')) {
                $upload_error = "目标目录不存在: ../uploads/";
            } else {
                // 检查目标目录是否可写
                if (!is_writable('../uploads/')) {
                    $upload_error = "目标目录不可写: ../uploads/";
                } else {
                    if (move_uploaded_file($file['tmp_name'], $upload_path)) {
                        $stmt = $db->prepare("INSERT INTO images (user_id, filename, original_name, file_size, file_type) VALUES (?, ?, ?, ?, ?)");
                        $stmt->execute([
                            $_SESSION['user_id'],
                            $new_filename,
                            $file['name'],
                            $file['size'],
                            $file['type']
                        ]);

                        $upload_success = "文件上传成功!";
                    } else {
                        $upload_error = "文件移动失败，请检查上传目录权限";
                        // 添加详细的错误信息
                        $errors = error_get_last();
                        $upload_error .= "<br>move_uploaded_file 错误: " . print_r($errors, true);
                    }
                }
            }
        }
    } else {
        $upload_error = "文件上传出错: " . $file['error'];
    }
}

// 图片删除处理
if (isset($_GET['delete'])) {
    $image_id = $_GET['delete'];

    // 验证图片属于当前用户
    $stmt = $db->prepare("SELECT * FROM images WHERE id = ? AND user_id = ?");
    $stmt->execute([$image_id, $_SESSION['user_id']]);
    $image = $stmt->fetch();

    if ($image) {
        // 删除文件
        $file_path = '../uploads/' . $image['filename'];
        if (file_exists($file_path)) {
            unlink($file_path);
        }

        // 删除数据库记录
        $stmt = $db->prepare("DELETE FROM images WHERE id = ?");
        $stmt->execute([$image_id]);

        header('Location: dashboard.php');
        exit;
    }
}

// 获取用户图片
$images = [];
$stmt = $db->prepare("SELECT * FROM images WHERE user_id = ? ORDER BY upload_date DESC");
$stmt->execute([$_SESSION['user_id']]);
$images = $stmt->fetchAll();

// 获取安装域名
$install_domain = $_SERVER['HTTP_HOST'];
?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../assess/css/style.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>用户仪表盘</title>
</head>

<body>
    <div class="container">
        <header>
            <div class="logo">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M4 8H20M8 4V20M7.8 20H16.2C17.8802 20 18.7202 20 19.362 19.673C19.9265 19.3854 20.3854 18.9265 20.673 18.362C21 17.7202 21 16.8802 21 15.2V8.8C21 7.11984 21 6.27976 20.673 5.63803C20.3854 5.07354 19.9265 4.6146 19.362 4.32698C18.7202 4 17.8802 4 16.2 4H7.8C6.11984 4 5.27976 4 4.63803 4.32698C4.07354 4.6146 3.6146 5.07354 3.32698 5.63803C3 6.27976 3 7.11984 3 8.8V15.2C3 16.8802 3 17.7202 3.32698 18.362C3.6146 18.9265 4.07354 19.3854 4.63803 19.673C5.27976 20 6.11984 20 7.8 20Z"
                        stroke="#4361ee" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    <circle cx="12" cy="12" r="2" stroke="#4361ee" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                </svg>
                <span>简洁图床</span>
            </div>

            <div class="user-info">
                <span>欢迎, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="../logout.php" class="logout-btn">退出登录</a>
            </div>
        </header>

        <div class="upload-area" id="upload-area">
            <h2>拖放文件到此处或点击上传</h2>
            <form action="dashboard.php" method="post" enctype="multipart/form-data">
                <input type="file" id="file-input" name="image" accept=".mp4,.png,.jpg,.jpeg,.gif,.webp,.heif">
                <label for="file-input" class="upload-btn">选择文件</label>
                <div class="file-types">支持格式: .mp4, .png, .jpg, .jpeg, .gif, .webp, .heif</div>
                <button type="submit" style="display:none;"></button>
            </form>

            <?php if (isset($upload_success)) : ?>
            <div class="success"><?php echo $upload_success; ?></div>
            <?php endif; ?>

            <?php if (isset($upload_error)) : ?>
            <div class="upload-error"><?php echo $upload_error; ?></div>
            <?php endif; ?>
        </div>

        <div class="gallery">
            <?php if (count($images) > 0) : ?>
            <?php foreach ($images as $image) : ?>
            <div class="image-card">
                <?php if (pathinfo($image['filename'], PATHINFO_EXTENSION) === 'mp4') : ?>
                <video width="100%" height="200" controls>
                    <source src="../uploads/<?php echo htmlspecialchars($image['filename']); ?>" type="video/mp4">
                    您的浏览器不支持视频播放
                </video>
                <?php else : ?>
                <img src="../uploads/<?php echo htmlspecialchars($image['filename']); ?>"
                    alt="<?php echo htmlspecialchars($image['original_name']); ?>">
                <?php endif; ?>
                <div class="image-info">
                    <div class="image-name"><?php echo htmlspecialchars($image['original_name']); ?></div>
                    <div class="image-meta">
                        <span><?php echo round($image['file_size'] / 1024, 2); ?> KB</span>
                        <span><?php echo date('Y-m-d', strtotime($image['upload_date'])); ?></span>
                    </div>
                    <div class="image-actions">
                        <a href="../uploads/<?php echo htmlspecialchars($image['filename']); ?>" target="_blank"
                            class="view-btn">查看</a>
                        <a href="dashboard.php?delete=<?php echo $image['id']; ?>" class="delete-btn"
                            onclick="return confirm('确定要删除这个文件吗？')">删除</a>
                        <?php
                            $image_url = "http://" . $install_domain . "/uploads/" . htmlspecialchars($image['filename']);
                        ?>
                        <button class="copy-btn" data-url="<?php echo $image_url; ?>">复制链接</button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php else : ?>
            <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M4 16L8.586 11.414C8.961 11.039 9.47 10.828 10 10.828C10.53 10.828 11.039 11.039 11.414 11.414L16 16M14 14L15.586 12.414C15.961 12.039 16.47 11.828 17 11.828C17.53 11.828 18.039 12.039 18.414 12.414L20 14M14 8H14.01M6 20H18C19.1046 20 20 19.1046 20 18V6C20 4.89543 19.1046 4 18 4H6C4.89543 4 4 4.89543 4 6V18C4 19.1046 4.89543 20 6 20Z"
                        stroke="#4361ee" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
                <h3>暂无文件</h3>
                <p>上传你的第一个文件开始使用</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // 拖放上传功能
        const uploadArea = document.getElementById('upload-area');
        const fileInput = document.getElementById('file-input');

        if (uploadArea) {
            uploadArea.addEventListener('click', () => {
                fileInput.click();
            });

            uploadArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                uploadArea.style.borderColor = '#4361ee';
                uploadArea.style.backgroundColor = 'rgba(67, 97, 238, 0.05)';
            });

            uploadArea.addEventListener('dragleave', () => {
                uploadArea.style.borderColor = '#ddd';
                uploadArea.style.backgroundColor = 'white';
            });

            uploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadArea.style.borderColor = '#ddd';
                uploadArea.style.backgroundColor = 'white';

                if (e.dataTransfer.files.length) {
                    fileInput.files = e.dataTransfer.files;
                    fileInput.closest('form').querySelector('button').click();
                }
            });

            fileInput.addEventListener('change', () => {
                if (fileInput.files.length) {
                    fileInput.closest('form').querySelector('button').click();
                }
            });
        }

        // 复制链接功能
        document.querySelectorAll('.copy-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const url = this.dataset.url;
                
                // 兼容性更好的复制方法
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(url)
                        .then(() => {
                            alert('链接已复制到剪贴板！');
                        })
                        .catch(err => {
                            console.error('复制失败: ', err);
                            copyToClipboardFallback(url); // 使用备用方法
                        });
                } else {
                    copyToClipboardFallback(url); // 使用备用方法
                }
            });
        });

        // 备用复制方法
        function copyToClipboardFallback(text) {
            const textarea = document.createElement("textarea");
            textarea.value = text;
            textarea.style.position = "fixed";  // 防止页面滚动
            document.body.appendChild(textarea);
            textarea.focus();
            textarea.select();

            try {
                const successful = document.execCommand('copy');
                const msg = successful ? '成功' : '失败';
                alert('链接复制' + msg + '！请手动复制。');
            } catch (err) {
                console.error('复制失败: ', err);
                alert('复制链接失败，请手动复制。');
            }

            document.body.removeChild(textarea);
        }
    </script>
</body>

</html>
