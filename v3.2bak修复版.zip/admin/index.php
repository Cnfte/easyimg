<?php
require_once '../config.php';

session_start();

// 检查用户是否登录
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin'])) {
    header('Location: ../index.php');
    exit;
}

// 数据库连接
try {
    $db = new PDO("mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}

// 获取用户数量
$stmt = $db->query("SELECT COUNT(*) FROM users");
$user_count = $stmt->fetchColumn();

// 获取图片数量
$stmt = $db->query("SELECT COUNT(*) FROM images");
$image_count = $stmt->fetchColumn();

// 获取运行时间
$start_time = $_SERVER['REQUEST_TIME'];
$current_time = time();
$uptime_seconds = $current_time - $start_time;

// 格式化运行时间
$uptime_days = floor($uptime_seconds / (60 * 60 * 24));
$uptime_hours = floor(($uptime_seconds % (60 * 60 * 24)) / (60 * 60));
$uptime_minutes = floor(($uptime_seconds % (60 * 60)) / 60);
$uptime_seconds = $uptime_seconds % 60;

$uptime_string = "{$uptime_days} 天 {$uptime_hours} 小时 {$uptime_minutes} 分 {$uptime_seconds} 秒";

// 获取当前时间
$current_datetime = date('Y-m-d H:i:s');

?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../assess/css/style.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="icon" href="../index.png" type="image/x-icon">
    <link rel="shortcut icon" href="../index.png" type="image/x-icon">
    <title>管理员控制台</title>
    <style>
        .dashboard-info {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 20px;
        }

        .info-card {
            background-color: #f2f2f2;
            border-radius: 5px;
            padding: 15px;
            margin: 10px;
            text-align: center;
            width: 300px;
        }

        .info-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .info-value {
            font-size: 16px;
        }
    </style>
</head>

<body>
    <div class="container">
        <header>
            <div class="logo">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M4 8H20M8 4V20M7.8 20H16.2C17.8802 20 18.7202 20 19.362 19.673C19.9265 19.3854 20.3854 18.9265 20.673 18.362C21 17.7202 21 16.8802 21 15.2V8.8C21 7.11984 21 6.27976 20.673 5.63803C20.3854 5.07354 19.9265 4.6146 19.362 4.32698C18.7202 4 17.8802 4 16.2 4H7.8C6.11984 4 5.27976 4 4.63803 4.32698C4.07354 4.6146 3.6146 5.07354 3.32698 5.63803C3 6.27976 3 7.11984 3 8.8V15.2C3 16.8802 3 17.7202 3.32698 18.362C3.6146 18.9265 4.07354 19.3854 4.63803 19.673C5.27976 20 6.11984 20 7.8 20Z"
                        stroke="#4361ee" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    <circle cx="12" cy="12" r="2" stroke="#4361ee" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                </svg>
                <span>简洁图床 - 管理员</span>
            </div>

            <div class="user-info">
                <span>管理员, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="../logout.php" class="logout-btn">退出登录</a>
            </div>
        </header>

        <div class="admin-panel">
            <h2>管理面板</h2>

            <div class="panel-options">
                <a href="users.php" class="option-btn">用户管理</a>
                <a href="images.php" class="option-btn">图片管理</a>
            </div>
        </div>

        <div class="dashboard-info">
            <div class="info-card">
                <div class="info-title">已注册用户数量</div>
                <div class="info-value"><?php echo htmlspecialchars($user_count); ?></div>
            </div>

            <div class="info-card">
                <div class="info-title">图片数量</div>
                <div class="info-value"><?php echo htmlspecialchars($image_count); ?></div>
            </div>

            <div class="info-card">
                <div class="info-title">运行时间</div>
                <div class="info-value"><?php echo htmlspecialchars($uptime_string); ?></div>
            </div>

            <div class="info-card">
                <div class="info-title">当前时间</div>
                <div class="info-value"><?php echo htmlspecialchars($current_datetime); ?></div>
            </div>
        </div>
    </div>
</body>

</html>
