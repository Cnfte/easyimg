<?php
require_once '../config.php';

// 数据库连接
try {
    $db = new PDO("mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}

// 验证处理
if (isset($_GET['token']) && isset($_GET['user_id'])) {
    $token = $_GET['token'];
    $user_id = $_GET['user_id'];

    // 验证 token 是否存在且未过期
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ? AND verification_token = ? AND register_time > DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
    $stmt->execute([$user_id, $token]);
    $user = $stmt->fetch();

    if ($user) {
        // 验证成功，更新 email_verified 字段
        $stmt = $db->prepare("UPDATE users SET email_verified = 1, verification_token = NULL WHERE id = ?");
        $stmt->execute([$user_id]);

        $verify_success = "邮箱验证成功，请登录";
    } else {
        $verify_error = "无效的验证链接或验证链接已过期";
    }
} else {
    $verify_error = "缺少参数";
}
?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../assess/css/style.css">
    <title>邮箱验证</title>
</head>

<body>
    <div class="container">
        <header>
            <div class="logo">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M4 8H20M8 4V20M7.8 20H16.2C17.8802 20 18.7202 20 19.362 19.673C19.9265 19.3854 20.3854 18.9265 20.673 18.362C21 17.7202 21 16.8802 21 15.2V8.8C21 7.11984 21 6.27976 20.673 5.63803C20.3854 5.07354 19.9265 4.6146 19.362 4.32698C18.7202 4 17.8802 4 16.2 4H7.8C6.11984 4 5.27976 4 4.63803 4.32698C4.07354 4.6146 3.6146 5.07354 3.32698 5.63803C3 6.27976 3 7.11984 3 8.8V15.2C3 16.8802 3 17.7202 3.32698 18.362C3.6146 18.9265 4.07354 19.3854 4.63803 19.673C5.27976 20 6.11984 20 7.8 20Z"
                        stroke="#4361ee" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    <circle cx="12" cy="12" r="2" stroke="#4361ee" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                </svg>
                <span>简洁图床</span>
            </div>
        </header>

        <div class="verify-form">
            <h2>邮箱验证</h2>

            <?php if (isset($verify_error)) : ?>
            <div class="error"><?php echo $verify_error; ?></div>
            <?php endif; ?>

            <?php if (isset($verify_success)) : ?>
            <div class="success"><?php echo $verify_success; ?></div>
            <?php endif; ?>

            <p style="text-align: center; margin-top: 15px;"><a href="../index.php#login" class="toggle-form">去登录</a></p>
        </div>
    </div>
</body>

</html>
