<?php
// 检查是否已安装
if (file_exists('config.php')) {
    header('Location: index.php');
    exit;
}

// 处理安装表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = $_POST['db_host'] ?? '';
    $db_port = $_POST['db_port'] ?? '3306'; // 默认端口
    $db_user = $_POST['db_user'] ?? '';
    $db_pass = $_POST['db_pass'] ?? '';
    $db_name = $_POST['db_name'] ?? '';
    $admin_user = $_POST['admin_user'] ?? '';
    $admin_pass = $_POST['admin_pass'] ?? '';
    $registration_mode = $_POST['registration_mode'] ?? 'normal'; // 默认普通注册
    $install_domain = $_POST['install_domain'] ?? ''; // 获取安装域名
    $smtp_from_email = $_POST['smtp_from_email'] ?? ''; // 获取发件人邮箱

    // 验证管理员密码
    if (strlen($admin_pass) < 8 || !preg_match('/[A-Z]/', $admin_pass) || !preg_match('/[a-z]/', $admin_pass) || !preg_match('/[0-9]/', $admin_pass)) {
        $error = "管理员密码必须至少 8 个字符，并且包含大小写字母和数字。";
    } else {
        // 测试数据库连接
        try {
            $db = new PDO("mysql:host=$db_host;port=$db_port;dbname=$db_name", $db_user, $db_pass);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // 创建表结构
            $sql = "
            CREATE TABLE IF NOT EXISTS `users` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `username` varchar(50) NOT NULL,
                `password` varchar(255) NOT NULL,
                `email` varchar(100) DEFAULT NULL,
                `email_verified` tinyint(1) NOT NULL DEFAULT '0',
                `verification_token` varchar(255) DEFAULT NULL,
                `ip_address` varchar(45) NOT NULL,
                `register_time` datetime NOT NULL,
                `login_attempts` INT(11) NOT NULL DEFAULT 0,
                `last_attempt_time` DATETIME DEFAULT NULL,
                `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `is_admin` tinyint(1) NOT NULL DEFAULT '0',
                PRIMARY KEY (`id`),
                UNIQUE KEY `username` (`username`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

            CREATE TABLE IF NOT EXISTS `images` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `user_id` int(11) NOT NULL,
                `filename` varchar(255) NOT NULL,
                `original_name` varchar(255) NOT NULL,
                `file_size` int(11) NOT NULL,
                `file_type` varchar(50) NOT NULL,
                `upload_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `user_id` (`user_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ";

            $db->exec($sql);

            // 创建管理员账户
            $hashed_pass = password_hash($admin_pass, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO `users` (`username`, `password`, `ip_address`, `register_time`, `is_admin`) VALUES (?, ?, ?, NOW(), 1)");
            $stmt->execute([$admin_user, $hashed_pass, '127.0.0.1']);

            // 创建配置文件
            $config_content = "<?php\n";
            $config_content .= "define('DB_HOST', '" . addslashes($db_host) . "');\n";
            $config_content .= "define('DB_PORT', '" . addslashes($db_port) . "');\n";
            $config_content .= "define('DB_USER', '" . addslashes($db_user) . "');\n";
            $config_content .= "define('DB_PASS', '" . addslashes($db_pass) . "');\n";
            $config_content .= "define('DB_NAME', '" . addslashes($db_name) . "');\n";
            $config_content .= "define('SMTP_FROM_EMAIL', '" . addslashes($smtp_from_email) . "');\n";
            $config_content .= "define('INSTALL_DOMAIN', '" . addslashes($install_domain) . "');\n"; // 保存安装域名
            $config_content .= "define('REGISTRATION_MODE', '" . addslashes($registration_mode) . "');\n";
            $config_content .= "?>";
            file_put_contents('config.php', $config_content);

            // 重定向到主页
            header('Location: index.php');
            exit;
        } catch (PDOException $e) {
            $error = "数据库连接失败: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="./assess/css/style.css">
    <title>图床系统安装向导</title>
    <style>
        /* 覆盖默认的选择框样式 */
        select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url('data:image/svg+xml;charset=UTF-8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%234361ee"><path d="M7 10l5 5 5-5z"/></svg>'); /* 自定义下拉箭头 */
            background-repeat: no-repeat;
            background-position: right 10px top 50%;
            background-size: 20px;
            padding: 12px 40px 12px 15px;
            border: 1px solid #ced4da;
            border-radius: var(--border-radius);
            font-size: 16px;
            color: #495057;
            width: 100%;
            transition: border-color var(--transition-duration) ease-in-out,
                        box-shadow var(--transition-duration) ease-in-out;
        }

        select:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.15);
        }

        /* 美化按钮样式 */
        button[type="submit"] {
            width: 100%;
            padding: 14px;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            font-size: 17px; /* 稍微增大字体 */
            font-weight: 600;
            cursor: pointer;
            transition: background-color var(--transition-duration) ease-in-out,
                        transform var(--transition-duration) ease-in-out;
        }

        button[type="submit"]:hover {
            background-color: var(--secondary-color);
            transform: translateY(-1px); /* 稍微上移 */
        }
    </style>
</head>

<body>
    <div class="install-container">
        <div class="logo">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M4 8H20M8 4V20M7.8 20H16.2C17.8802 20 18.7202 20 19.362 19.673C19.9265 19.3854 20.3854 18.9265 20.673 18.362C21 17.7202 21 16.8802 21 15.2V8.8C21 7.11984 21 6.27976 20.673 5.63803C20.3854 5.07354 19.9265 4.6146 19.362 4.32698C18.7202 4 17.8802 4 16.2 4H7.8C6.11984 4 5.27976 4 4.63803 4.32698C4.07354 4.6146 3.6146 5.07354 3.32698 5.63803C3 6.27976 3 7.11984 3 8.8V15.2C3 16.8802 3 17.7202 3.32698 18.362C3.6146 18.9265 4.07354 19.3854 4.63803 19.673C5.27976 20 6.11984 20 7.8 20Z"
                    stroke="#4361ee" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                <circle cx="12" cy="12" r="2" stroke="#4361ee" stroke-width="2" stroke-linecap="round"
                    stroke-linejoin="round" />
            </svg>
        </div>
        <h1>图床系统安装向导</h1>

        <?php if (isset($error)) : ?>
        <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label for="db_host">数据库地址</label>
                <input type="text" id="db_host" name="db_host" value="localhost" required>
            </div>

            <div class="form-group">
                <label for="db_port">数据库端口 (默认 3306)</label>
                <input type="number" id="db_port" name="db_port" value="3306">
            </div>

            <div class="form-group">
                <label for="db_user">数据库用户名</label>
                <input type="text" id="db_user" name="db_user" value="root" required>
            </div>

            <div class="form-group">
                <label for="db_pass">数据库密码</label>
                <input type="password" id="db_pass" name="db_pass">
            </div>

            <div class="form-group">
                <label for="db_name">数据库名</label>
                <input type="text" id="db_name" name="db_name" required>
            </div>

            <div class="form-group">
                <label for="admin_user">管理员用户名</label>
                <input type="text" id="admin_user" name="admin_user" value="admin" required>
            </div>

            <div class="form-group">
                <label for="admin_pass">管理员密码 (至少 8 个字符，包含大小写字母和数字)</label>
                <input type="password" id="admin_pass" name="admin_pass" required>
            </div>

            <div class="form-group">
                <label for="install_domain">安装域名</label>
                <input type="text" id="install_domain" name="install_domain" required>
            </div>

            <div class="form-group">
                <label for="registration_mode">注册方式</label>
                <select id="registration_mode" name="registration_mode">
                    <option value="normal">普通注册</option>
                    <option value="disabled">禁用注册</option>
                </select>
            </div>

            <button type="submit">开始安装</button>
        </form>
    </div>
</body>

</html>
