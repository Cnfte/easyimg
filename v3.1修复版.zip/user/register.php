<?php
require_once '../config.php';

// 注册模式判断
if (REGISTRATION_MODE == 'disabled') {
    header('Location: ../index.php');
    exit;
}

session_start();

// 数据库连接
try {
    $db = new PDO("mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}

// 注册处理
if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $captcha = $_POST['captcha'];
    $ip_address = $_SERVER['REMOTE_ADDR'];

    // 验证码校验
    if (strtolower($captcha) != strtolower($_SESSION['captcha'])) {
        $register_error = "验证码错误";
    } else {
        // 检查 IP 是否在 5 分钟内注册过
        $stmt = $db->prepare("SELECT * FROM users WHERE ip_address = ? AND register_time > DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
        $stmt->execute([$ip_address]);

        if ($stmt->rowCount() > 0) {
            $register_error = "每个 IP 地址 5 分钟内只能注册一个账户";
        } else {
            // 检查用户名是否已存在
            $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);

            if ($stmt->rowCount() > 0) {
                $register_error = "用户名已存在";
            } else {
                // 普通注册
                $hashed_pass = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $db->prepare("INSERT INTO users (username, password, ip_address, register_time) VALUES (?, ?, ?, NOW())");
                $stmt->execute([$username, $hashed_pass, $ip_address]);

                $register_success = "注册成功，请登录";
            }
        }
    }
}

// 生成验证码
$captcha_code = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"), 0, 6);
$_SESSION['captcha'] = $captcha_code;

header('Content-type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../assess/css/style.css">
    <link rel="icon" href="../index.png" type="image/x-icon">
    <link rel="shortcut icon" href="../index.png" type="image/x-icon">
    <title>用户注册</title>
    <style>
        .captcha-image {
            width: 150px;
            height: 50px;
            border: 1px solid #ccc;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div class="container">
        <header>
            <div class="logo">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M4 8H20M8 4V20M7.8 20H16.2C17.8802 20 18.7202 20 19.362 19.673C19.9265 19.3854 20.3854 18.9265 20.673 18.362C21 17.7202 21 16.8802 21 15.2V8.8C21 7.11984 21 6.27976 20.673 5.63803C20.3854 5.07354 19.9265 4.6146 19.362 4.32698C18.7202 4 17.8802 4 16.2 4H7.8C6.11984 4 5.27976 4 4.63803 4.32698C4.07354 4.6146 3.6146 5.07354 3.32698 5.63803C3 6.27976 3 7.11984 3 8.8V15.2C3 16.8802 3 17.7202 3.32698 18.362C3.6146 18.9265 4.07354 19.3854 4.63803 19.673C5.27976 20 6.11984 20 7.8 20Z"
                        stroke="#4361ee" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    <circle cx="12" cy="12" r="2" stroke="#4361ee" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                </svg>
                <span>简洁图床</span>
            </div>
        </header>

        <div class="register-form">
            <h2>用户注册</h2>

            <?php if (isset($register_error)) : ?>
            <div class="error"><?php echo $register_error; ?></div>
            <?php endif; ?>

            <?php if (isset($register_success)) : ?>
            <div class="success"><?php echo $register_success; ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label for="reg_username">用户名</label>
                    <input type="text" id="reg_username" name="username" required>
                </div>

                <div class="form-group">
                    <label for="reg_password">密码</label>
                    <input type="password" id="reg_password" name="password" required>
                </div>

                <div class="form-group">
                    <label for="captcha">验证码</label>
                    <img src="../captcha.php" alt="验证码" class="captcha-image">
                    <input type="text" id="captcha" name="captcha" required>
                </div>

                <button type="submit" name="register" class="submit-btn">注册</button>
                <p style="text-align: center; margin-top: 15px;">已有账号？<a href="../index.php#login"
                        class="toggle-form">去登录</a></p>
            </form>
        </div>
    </div>
</body>

</html>
