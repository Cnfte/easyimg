<?php
// 检查是否已安装
if(!file_exists('config.php')) {
    header('Location: install.php');
    exit;
}

require_once 'config.php';

// 数据库连接
try {
    $db = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}

session_start();

// 登录处理
if(isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        header('Location: index.php');
        exit;
    } else {
        $login_error = "用户名或密码错误";
    }
}

// 注册处理
if(isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $ip_address = $_SERVER['REMOTE_ADDR'];
    
    // 检查IP是否在60分钟内注册过
    $stmt = $db->prepare("SELECT * FROM users WHERE ip_address = ? AND register_time > DATE_SUB(NOW(), INTERVAL 60 MINUTE)");
    $stmt->execute([$ip_address]);
    
    if($stmt->rowCount() > 0) {
        $register_error = "每个IP地址60分钟内只能注册一个账户";
    } else {
        // 检查用户名是否已存在
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        
        if($stmt->rowCount() > 0) {
            $register_error = "用户名已存在";
        } else {
            // 创建用户
            $hashed_pass = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO users (username, password, ip_address, register_time) VALUES (?, ?, ?, NOW())");
            $stmt->execute([$username, $hashed_pass, $ip_address]);
            
            $register_success = "注册成功，请登录";
        }
    }
}

// 登出处理
if(isset($_GET['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit;
}

// 文件上传处理
if(isset($_FILES['image']) && isset($_SESSION['user_id'])) {
    $file = $_FILES['image'];
    $allowed_extensions = ['mp4', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'heif'];
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if($file['error'] === UPLOAD_ERR_OK) {
        // 检查文件类型
        if(!in_array($file_ext, $allowed_extensions)) {
            $upload_error = "只允许上传以下格式的文件: .mp4, .png, .jpg, .jpeg, .gif, .webp, .heif";
        } else {
            $new_filename = uniqid() . '.' . $file_ext;
            $upload_path = 'uploads/' . $new_filename;
            
            if(move_uploaded_file($file['tmp_name'], $upload_path)) {
                $stmt = $db->prepare("INSERT INTO images (user_id, filename, original_name, file_size, file_type) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([
                    $_SESSION['user_id'],
                    $new_filename,
                    $file['name'],
                    $file['size'],
                    $file['type']
                ]);
                
                $upload_success = "文件上传成功!";
            } else {
                $upload_error = "文件移动失败，请检查上传目录权限";
            }
        }
    } else {
        $upload_error = "文件上传出错: " . $file['error'];
    }
}

// 图片删除处理
if(isset($_GET['delete']) && isset($_SESSION['user_id'])) {
    $image_id = $_GET['delete'];
    
    // 验证图片属于当前用户
    $stmt = $db->prepare("SELECT * FROM images WHERE id = ? AND user_id = ?");
    $stmt->execute([$image_id, $_SESSION['user_id']]);
    $image = $stmt->fetch();
    
    if($image) {
        // 删除文件
        $file_path = 'uploads/' . $image['filename'];
        if(file_exists($file_path)) {
            unlink($file_path);
        }
        
        // 删除数据库记录
        $stmt = $db->prepare("DELETE FROM images WHERE id = ?");
        $stmt->execute([$image_id]);
        
        header('Location: index.php');
        exit;
    }
}

// 获取用户图片
$images = [];
if(isset($_SESSION['user_id'])) {
    $stmt = $db->prepare("SELECT * FROM images WHERE user_id = ? ORDER BY upload_date DESC");
    $stmt->execute([$_SESSION['user_id']]);
    $images = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>简洁图床系统</title>
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4cc9f0;
            --danger-color: #e63946;
            --border-radius: 12px;
            --box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f7ff;
            color: var(--dark-color);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 0;
            border-bottom: 1px solid #eee;
            margin-bottom: 30px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            font-weight: 600;
            font-size: 20px;
            color: var(--primary-color);
        }
        
        .logo svg {
            width: 30px;
            height: 30px;
            margin-right: 10px;
        }
        
        .auth-buttons a {
            padding: 8px 16px;
            border-radius: var(--border-radius);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .login-btn {
            color: var(--primary-color);
            margin-right: 10px;
        }
        
        .login-btn:hover {
            background-color: rgba(67, 97, 238, 0.1);
        }
        
        .register-btn {
            background-color: var(--primary-color);
            color: white;
        }
        
        .register-btn:hover {
            background-color: var(--secondary-color);
        }
        
        .user-info {
            display: flex;
            align-items: center;
        }
        
        .user-info span {
            margin-right: 15px;
            font-weight: 500;
        }
        
        .logout-btn {
            color: var(--danger-color);
            text-decoration: none;
            padding: 8px 16px;
            border-radius: var(--border-radius);
        }
        
        .logout-btn:hover {
            background-color: rgba(230, 57, 70, 0.1);
        }
        
        .upload-area {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 30px;
            margin-bottom: 30px;
            text-align: center;
            border: 2px dashed #ddd;
            transition: all 0.3s;
        }
        
        .upload-area:hover {
            border-color: var(--primary-color);
        }
        
        .upload-area h2 {
            margin-bottom: 20px;
            color: var(--dark-color);
        }
        
        .upload-btn {
            display: inline-block;
            background-color: var(--primary-color);
            color: white;
            padding: 12px 24px;
            border-radius: var(--border-radius);
            cursor: pointer;
            transition: all 0.3s;
            font-weight: 500;
            margin-top: 15px;
        }
        
        .upload-btn:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
        }
        
        #file-input {
            display: none;
        }
        
        .gallery {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        
        .image-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
            transition: all 0.3s;
        }
        
        .image-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }
        
        .image-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
        
        .image-info {
            padding: 15px;
        }
        
        .image-name {
            font-weight: 500;
            margin-bottom: 5px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .image-meta {
            font-size: 12px;
            color: #666;
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .image-actions {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        
        .view-btn, .delete-btn {
            display: inline-block;
            padding: 8px 0;
            border-radius: var(--border-radius);
            text-decoration: none;
            font-size: 14px;
            text-align: center;
            transition: all 0.3s;
            flex: 1;
        }
        
        .view-btn {
            background-color: var(--primary-color);
            color: white;
        }
        
        .view-btn:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
        }
        
        .delete-btn {
            background-color: var(--danger-color);
            color: white;
        }
        
        .delete-btn:hover {
            background-color: #c1121f;
            transform: translateY(-2px);
        }
        
        .login-form, .register-form {
            max-width: 400px;
            margin: 50px auto;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 40px;
        }
        
        .login-form h2, .register-form h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 16px;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }
        
        .submit-btn {
            width: 100%;
            padding: 14px;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .submit-btn:hover {
            background-color: var(--secondary-color);
        }
        
        .error, .upload-error {
            color: var(--danger-color);
            margin-bottom: 20px;
            text-align: center;
        }
        
        .success {
            color: var(--success-color);
            margin-bottom: 20px;
            text-align: center;
        }
        
        .empty-state {
            text-align: center;
            padding: 50px;
            color: #666;
            grid-column: 1 / -1;
        }
        
        .empty-state svg {
            width: 80px;
            height: 80px;
            margin-bottom: 20px;
            opacity: 0.6;
        }
        
        .toggle-form {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
        }
        
        .toggle-form:hover {
            text-decoration: underline;
        }
        
        .register-form {
            display: none;
        }
        
        .file-types {
            font-size: 14px;
            color: #666;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4 8H20M8 4V20M7.8 20H16.2C17.8802 20 18.7202 20 19.362 19.673C19.9265 19.3854 20.3854 18.9265 20.673 18.362C21 17.7202 21 16.8802 21 15.2V8.8C21 7.11984 21 6.27976 20.673 5.63803C20.3854 5.07354 19.9265 4.6146 19.362 4.32698C18.7202 4 17.8802 4 16.2 4H7.8C6.11984 4 5.27976 4 4.63803 4.32698C4.07354 4.6146 3.6146 5.07354 3.32698 5.63803C3 6.27976 3 7.11984 3 8.8V15.2C3 16.8802 3 17.7202 3.32698 18.362C3.6146 18.9265 4.07354 19.3854 4.63803 19.673C5.27976 20 6.11984 20 7.8 20Z" stroke="#4361ee" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <circle cx="12" cy="12" r="2" stroke="#4361ee" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <span>简洁图床</span>
            </div>
            
            <?php if(isset($_SESSION['username'])): ?>
                <div class="user-info">
                    <span>欢迎, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    <a href="?logout=1" class="logout-btn">退出登录</a>
                </div>
            <?php else: ?>
                <div class="auth-buttons">
                    <a href="#login" class="login-btn">登录</a>
                    <a href="#register" class="register-btn">注册</a>
                </div>
            <?php endif; ?>
        </header>
        
        <?php if(isset($_SESSION['username'])): ?>
            <div class="upload-area" id="upload-area">
                <h2>拖放文件到此处或点击上传</h2>
                <form action="index.php" method="post" enctype="multipart/form-data">
                    <input type="file" id="file-input" name="image" accept=".mp4,.png,.jpg,.jpeg,.gif,.webp,.heif">
                    <label for="file-input" class="upload-btn">选择文件</label>
                    <div class="file-types">支持格式: .mp4, .png, .jpg, .jpeg, .gif, .webp, .heif</div>
                    <button type="submit" style="display:none;"></button>
                </form>
                
                <?php if(isset($upload_success)): ?>
                    <div class="success"><?php echo $upload_success; ?></div>
                <?php endif; ?>
                
                <?php if(isset($upload_error)): ?>
                    <div class="upload-error"><?php echo $upload_error; ?></div>
                <?php endif; ?>
            </div>
            
            <div class="gallery">
                <?php if(count($images) > 0): ?>
                    <?php foreach($images as $image): ?>
                        <div class="image-card">
                            <?php if(pathinfo($image['filename'], PATHINFO_EXTENSION) === 'mp4'): ?>
                                <video width="100%" height="200" controls>
                                    <source src="uploads/<?php echo htmlspecialchars($image['filename']); ?>" type="video/mp4">
                                    您的浏览器不支持视频播放
                                </video>
                            <?php else: ?>
                                <img src="uploads/<?php echo htmlspecialchars($image['filename']); ?>" alt="<?php echo htmlspecialchars($image['original_name']); ?>">
                            <?php endif; ?>
                            <div class="image-info">
                                <div class="image-name"><?php echo htmlspecialchars($image['original_name']); ?></div>
                                <div class="image-meta">
                                    <span><?php echo round($image['file_size'] / 1024, 2); ?> KB</span>
                                    <span><?php echo date('Y-m-d', strtotime($image['upload_date'])); ?></span>
                                </div>
                                <div class="image-actions">
                                    <a href="uploads/<?php echo htmlspecialchars($image['filename']); ?>" target="_blank" class="view-btn">查看</a>
                                    <a href="?delete=<?php echo $image['id']; ?>" class="delete-btn" onclick="return confirm('确定要删除这个文件吗？')">删除</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4 16L8.586 11.414C8.961 11.039 9.47 10.828 10 10.828C10.53 10.828 11.039 11.039 11.414 11.414L16 16M14 14L15.586 12.414C15.961 12.039 16.47 11.828 17 11.828C17.53 11.828 18.039 12.039 18.414 12.414L20 14M14 8H14.01M6 20H18C19.1046 20 20 19.1046 20 18V6C20 4.89543 19.1046 4 18 4H6C4.89543 4 4 4.89543 4 6V18C4 19.1046 4.89543 20 6 20Z" stroke="#4361ee" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <h3>暂无文件</h3>
                        <p>上传你的第一个文件开始使用</p>
                    </div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="login-form" id="login">
                <h2>用户登录</h2>
                
                <?php if(isset($login_error)): ?>
                    <div class="error"><?php echo $login_error; ?></div>
                <?php endif; ?>
                
                <form method="POST">
                    <div class="form-group">
                        <label for="username">用户名</label>
                        <input type="text" id="username" name="username" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">密码</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    
                    <button type="submit" name="login" class="submit-btn">登录</button>
                    <p style="text-align: center; margin-top: 15px;">没有账号？<a href="#register" class="toggle-form">去注册</a></p>
                </form>
            </div>
            
            <div class="register-form" id="register">
                <h2>用户注册</h2>
                
                <?php if(isset($register_error)): ?>
                    <div class="error"><?php echo $register_error; ?></div>
                <?php endif; ?>
                
                <?php if(isset($register_success)): ?>
                    <div class="success"><?php echo $register_success; ?></div>
                <?php endif; ?>
                
                <form method="POST">
                    <div class="form-group">
                        <label for="reg_username">用户名</label>
                        <input type="text" id="reg_username" name="username" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="reg_password">密码</label>
                        <input type="password" id="reg_password" name="password" required>
                    </div>
                    
                    <button type="submit" name="register" class="submit-btn">注册</button>
                    <p style="text-align: center; margin-top: 15px;">已有账号？<a href="#login" class="toggle-form">去登录</a></p>
                </form>
            </div>
        <?php endif; ?>
    </div>
    
    <script>
        // 拖放上传功能
        const uploadArea = document.getElementById('upload-area');
        const fileInput = document.getElementById('file-input');
        
        if(uploadArea) {
            uploadArea.addEventListener('click', () => {
                fileInput.click();
            });
            
            uploadArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                uploadArea.style.borderColor = '#4361ee';
                uploadArea.style.backgroundColor = 'rgba(67, 97, 238, 0.05)';
            });
            
            uploadArea.addEventListener('dragleave', () => {
                uploadArea.style.borderColor = '#ddd';
                uploadArea.style.backgroundColor = 'white';
            });
            
            uploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadArea.style.borderColor = '#ddd';
                uploadArea.style.backgroundColor = 'white';
                
                if(e.dataTransfer.files.length) {
                    fileInput.files = e.dataTransfer.files;
                    fileInput.closest('form').querySelector('button').click();
                }
            });
            
            fileInput.addEventListener('change', () => {
                if(fileInput.files.length) {
                    fileInput.closest('form').querySelector('button').click();
                }
            });
        }
        
        // 表单切换功能
        document.querySelectorAll('.login-btn, .register-btn, .toggle-form').forEach(btn => {
            btn.addEventListener('click', function(e) {
                if(this.getAttribute('href') === '#login' || this.classList.contains('login-btn')) {
                    document.querySelector('.login-form').style.display = 'block';
                    document.querySelector('.register-form').style.display = 'none';
                } else if(this.getAttribute('href') === '#register' || this.classList.contains('register-btn')) {
                    document.querySelector('.login-form').style.display = 'none';
                    document.querySelector('.register-form').style.display = 'block';
                }
                
                if(this.getAttribute('href')?.startsWith('#')) {
                    e.preventDefault();
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                }
            });
        });
        
        // 默认显示登录表单
        if(document.querySelector('.login-form')) {
            document.querySelector('.login-form').style.display = 'block';
        }
    </script>
</body>
</html>